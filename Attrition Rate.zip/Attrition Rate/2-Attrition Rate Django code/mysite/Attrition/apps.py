from django.apps import AppConfig


class AttritionConfig(AppConfig):
    name = 'Attrition'
